package com.capgemini.tcc.ui;

import java.util.Scanner;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.service.PatientService;

final class Client {

	public static void main(String[] args) {
		
		System.out.println("1. Add Patient Information");
		System.out.println("2. Search Patient by Id");
		System.out.println("3. Exit");
		
		Scanner s=new Scanner(System.in);
		int i=s.nextInt();
		PatientBean patient=new PatientBean();
		PatientDAO obj=new PatientDAO();
		PatientService ps=new PatientService();
		switch (i)
		{
		case 1:
			System.out.print("Enter the name of the Patient:");
			String name=s.next();
			patient.setPatientName(name);
			System.out.print("Enter Patient Age:");
			int age=s.nextInt();
			patient.setPatientAge(age);
			System.out.print("Enter Patient phone number:");
			long mobile_number=s.nextLong();
			patient.setPatientPhoneNumber(mobile_number);
			System.out.print("Enter Description:");
			String desc=s.next();
			patient.setDescription(desc);
			obj.addPatientdetails(patient);
			//obj.addPatientdetails(patient);
			break;
			
		case 2:
			System.out.println("Enter the Patient Id to be searched:");
			int id=s.nextInt();
			patient.setPatientId(id);
			ps.getPatientDetails(id);
			break;
			
		case 3:
			System.exit(0);
			break;
		}
		

	}

}
