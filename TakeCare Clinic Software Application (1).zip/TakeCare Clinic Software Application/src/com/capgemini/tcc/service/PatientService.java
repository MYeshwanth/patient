package com.capgemini.tcc.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.connection.CommonConnection;

public class PatientService implements IPatientService {
	private Connection cn;


	public int addPatientdetails(PatientBean patient) {
		
		return 0;
	}	
	public PatientBean getPatientDetails(int patientID) {
		try {
			cn=CommonConnection.getcon();
			Statement st=cn.createStatement();			
			int i=st.executeUpdate("select * from patient where patient_id="+patientID);	
			
			
	   	 if(i>0) {
	   		ResultSet rs=st.executeQuery("select * from patient where patient_id="+patientID);
	   		
	   		while(rs.next())
	   	 {
	   			System.out.println(i);
	   		 System.out.println("Name of the Patient"+rs.getString(2)+"\nAge"+rs.getInt(3)+"\nPhone Number"+rs.getInt(4)+"\nDescription"+rs.getInt(5)+"\nConsultation Date"+rs.getInt(6));
	   	 }
		} 
	   	 else 
	   	 {
	   		 System.out.println("result not found");}
	   	
		} catch (Exception e) {			
			e.printStackTrace();
		}   	 
		return null;
	}
	

}
